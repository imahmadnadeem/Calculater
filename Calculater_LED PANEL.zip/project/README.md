# LED Display Calculator

A professional web application for calculating LED display resolutions for Adobe After Effects projects.

## Features

- Calculate total pixel dimensions based on physical LED display specifications
- Real-time validation and error handling
- Responsive design that works on mobile, tablet, and desktop
- Clear results display formatted for After Effects

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Open your browser to the URL shown in the terminal

## Usage

1. Enter your LED display specifications:
   - Display Width (mm)
   - Display Height (mm)
   - Panel Width (mm)
   - Panel Height (mm)
   - Panel Resolution Width (pixels)
   - Panel Resolution Height (pixels)

2. Click "Calculate" to get your results

3. Use the calculated dimensions in After Effects for your screen size

## Development

- Run tests: `npm test`
- Build for production: `npm run build`
- Preview production build: `npm run preview`

## Technologies Used

- React
- Vite
- Mantine UI
- Vitest for testing
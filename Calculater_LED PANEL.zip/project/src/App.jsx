import { ThemeProvider, CssBaseline } from '@mui/material';
import { theme } from './theme';
import Layout from './components/Layout';
import ImageEditor from './components/ImageEditor';

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Layout>
        <ImageEditor />
      </Layout>
    </ThemeProvider>
  );
}

export default App;
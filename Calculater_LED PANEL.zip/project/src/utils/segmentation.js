import * as tf from '@tensorflow/tfjs';
import * as bodySegmentation from '@tensorflow-models/body-segmentation';

let segmenter = null;

export async function initializeSegmenter() {
  if (!segmenter) {
    segmenter = await bodySegmentation.createSegmenter(
      bodySegmentation.SupportedModels.MediaPipeSelfieSegmentation,
      {
        runtime: 'tfjs',
        modelType: 'general'
      }
    );
  }
  return segmenter;
}

export async function segmentImage(imageElement) {
  const segmenter = await initializeSegmenter();
  const segmentation = await segmenter.segmentPeople(imageElement);
  
  // Extract person and background
  const foregroundMask = await segmentation[0].mask.toImageData();
  const backgroundMask = invertMask(foregroundMask);
  
  return {
    foreground: await createMaskedImage(imageElement, foregroundMask),
    background: await createMaskedImage(imageElement, backgroundMask)
  };
}

function invertMask(mask) {
  const data = mask.data;
  const inverted = new ImageData(mask.width, mask.height);
  for (let i = 0; i < data.length; i += 4) {
    inverted.data[i] = 255 - data[i];
    inverted.data[i + 1] = 255 - data[i + 1];
    inverted.data[i + 2] = 255 - data[i + 2];
    inverted.data[i + 3] = data[i + 3];
  }
  return inverted;
}

async function createMaskedImage(image, mask) {
  const canvas = document.createElement('canvas');
  canvas.width = mask.width;
  canvas.height = mask.height;
  const ctx = canvas.getContext('2d');
  
  ctx.putImageData(mask, 0, 0);
  ctx.globalCompositeOperation = 'source-in';
  ctx.drawImage(image, 0, 0);
  
  return canvas.toDataURL();
}
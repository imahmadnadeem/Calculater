export const calculateDisplayResolution = (
  displayWidth,
  displayHeight,
  panelWidth,
  panelHeight,
  panelResWidth,
  panelResHeight
) => {
  // Convert all inputs to numbers and validate
  const inputs = [displayWidth, displayHeight, panelWidth, panelHeight, panelResWidth, panelResHeight]
  const numbers = inputs.map(input => Number(input))
  
  if (numbers.some(num => isNaN(num) || num <= 0)) {
    throw new Error('All inputs must be positive numbers')
  }

  const [dw, dh, pw, ph, prw, prh] = numbers

  // Calculate total pixels
  const totalHorizontalPixels = Math.round((dw / pw) * prw)
  const totalVerticalPixels = Math.round((dh / ph) * prh)
  const totalPixelCount = totalHorizontalPixels * totalVerticalPixels

  return {
    horizontalPixels: totalHorizontalPixels,
    verticalPixels: totalVerticalPixels,
    totalPixels: totalPixelCount
  }
}
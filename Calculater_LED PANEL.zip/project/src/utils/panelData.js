export const panelModels = [
  {
    label: 'P1.99 Indoor LED Panel',
    width: 500,
    height: 500,
    pixelPitch: 1.99,
    resolutionWidth: 251,
    resolutionHeight: 251
  },
  {
    label: 'P2.6 Indoor LED Panel',
    width: 500,
    height: 500,
    pixelPitch: 2.6,
    resolutionWidth: 192,
    resolutionHeight: 192
  },
  {
    label: 'P2.9 Indoor LED Panel',
    width: 500,
    height: 500,
    pixelPitch: 2.9,
    resolutionWidth: 172,
    resolutionHeight: 172
  },
  {
    label: 'P3.91 Indoor LED Panel',
    width: 500,
    height: 500,
    pixelPitch: 3.91,
    resolutionWidth: 128,
    resolutionHeight: 128
  },
  {
    label: 'P3.91 Outdoor LED Panel',
    width: 500,
    height: 500,
    pixelPitch: 3.91,
    resolutionWidth: 128,
    resolutionHeight: 128
  },
  {
    label: 'P4.81 Outdoor LED Panel',
    width: 500,
    height: 500,
    pixelPitch: 4.81,
    resolutionWidth: 104,
    resolutionHeight: 104
  }
]
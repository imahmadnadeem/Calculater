export function adjustImageLayer(imageData, adjustments) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const img = new Image();
  
  return new Promise((resolve) => {
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      
      for (let i = 0; i < data.length; i += 4) {
        // Brightness
        if (adjustments.brightness) {
          data[i] = clamp(data[i] + adjustments.brightness);
          data[i + 1] = clamp(data[i + 1] + adjustments.brightness);
          data[i + 2] = clamp(data[i + 2] + adjustments.brightness);
        }
        
        // Contrast
        if (adjustments.contrast) {
          const factor = (259 * (adjustments.contrast + 255)) / (255 * (259 - adjustments.contrast));
          data[i] = clamp(factor * (data[i] - 128) + 128);
          data[i + 1] = clamp(factor * (data[i + 1] - 128) + 128);
          data[i + 2] = clamp(factor * (data[i + 2] - 128) + 128);
        }
      }
      
      ctx.putImageData(imageData, 0, 0);
      resolve(canvas.toDataURL());
    };
    img.src = imageData;
  });
}

function clamp(value) {
  return Math.max(0, Math.min(255, value));
}
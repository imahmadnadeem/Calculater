import { Paper, List, ListItem, ListItemText, IconButton, Box, Typography, Slider } from '@mui/material';
import { Visibility, VisibilityOff, Lock, LockOpen } from '@mui/icons-material';
import { useImageStore } from '../store/imageStore';

export default function LayerPanel() {
  const layers = useImageStore(state => state.layers);
  const toggleLayerVisibility = useImageStore(state => state.toggleLayerVisibility);
  const toggleLayerLock = useImageStore(state => state.toggleLayerLock);
  const adjustLayer = useImageStore(state => state.adjustLayer);

  const handleAdjustment = (layerId, type, value) => {
    adjustLayer(layerId, { [type]: value });
  };

  return (
    <Paper sx={{ width: 300, overflow: 'auto' }}>
      <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
        <Typography variant="h6">Layers</Typography>
      </Box>
      <List>
        {layers.map((layer) => (
          <Box key={layer.id}>
            <ListItem
              secondaryAction={
                <>
                  <IconButton 
                    edge="end" 
                    onClick={() => toggleLayerVisibility(layer.id)}
                  >
                    {layer.visible ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                  <IconButton 
                    edge="end" 
                    onClick={() => toggleLayerLock(layer.id)}
                  >
                    {layer.locked ? <Lock /> : <LockOpen />}
                  </IconButton>
                </>
              }
            >
              <ListItemText primary={layer.name} />
            </ListItem>
            
            <Box sx={{ px: 2, pb: 2 }}>
              <Typography gutterBottom>Brightness</Typography>
              <Slider
                size="small"
                min={-100}
                max={100}
                value={layer.adjustments?.brightness || 0}
                onChange={(_, value) => handleAdjustment(layer.id, 'brightness', value)}
                disabled={layer.locked}
              />
              
              <Typography gutterBottom>Contrast</Typography>
              <Slider
                size="small"
                min={-100}
                max={100}
                value={layer.adjustments?.contrast || 0}
                onChange={(_, value) => handleAdjustment(layer.id, 'contrast', value)}
                disabled={layer.locked}
              />
            </Box>
          </Box>
        ))}
      </List>
    </Paper>
  );
}
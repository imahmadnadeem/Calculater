import { useState } from 'react'
import { TextInput, Button, Paper, Title, Text, Container, Grid, NumberInput, Select, Tooltip, Switch, Box, useMantineColorScheme } from '@mantine/core'
import { IconBulb, IconCheck, IconMoonStars, IconSun } from '@tabler/icons-react'
import { calculateDisplayResolution } from '../utils/calculations'
import { panelModels } from '../utils/panelData'

const initialState = {
  displayWidth: '',
  displayHeight: '',
  panelWidth: '',
  panelHeight: '',
  panelResWidth: '',
  panelResHeight: ''
}

export function Calculator() {
  const [inputs, setInputs] = useState(initialState)
  const [results, setResults] = useState(null)
  const [error, setError] = useState('')
  const [selectedPanel, setSelectedPanel] = useState(null)
  const { colorScheme, toggleColorScheme } = useMantineColorScheme()

  const handlePanelSelect = (value) => {
    const panel = panelModels.find(p => p.label === value)
    if (panel) {
      setSelectedPanel(value)
      setInputs(prev => ({
        ...prev,
        panelWidth: panel.width,
        panelHeight: panel.height,
        panelResWidth: panel.resolutionWidth,
        panelResHeight: panel.resolutionHeight
      }))
    }
  }

  const handleInputChange = (name, value) => {
    setInputs(prev => ({
      ...prev,
      [name]: value
    }))
    if (['panelWidth', 'panelHeight', 'panelResWidth', 'panelResHeight'].includes(name)) {
      setSelectedPanel(null)
    }
    setError('')
  }

  const handleCalculate = () => {
    try {
      const result = calculateDisplayResolution(
        inputs.displayWidth,
        inputs.displayHeight,
        inputs.panelWidth,
        inputs.panelHeight,
        inputs.panelResWidth,
        inputs.panelResHeight
      )
      setResults(result)
      setError('')
    } catch (err) {
      setError(err.message)
      setResults(null)
    }
  }

  return (
    <Container size="md">
      <Paper shadow="sm" p="xl" mt="xl" radius="md">
        <Box sx={{ position: 'absolute', top: 20, right: 20 }}>
          <Switch
            size="md"
            color={colorScheme === 'dark' ? 'blue' : 'dark'}
            onLabel={<IconSun size={16} />}
            offLabel={<IconMoonStars size={16} />}
            onChange={() => toggleColorScheme()}
          />
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '2rem' }}>
          <IconBulb size={32} stroke={1.5} />
          <Title order={1} align="center" sx={{ fontSize: '2.2rem', fontWeight: 600 }}>
            Advanced LED Panel Configurator
          </Title>
        </Box>
        
        <Grid>
          <Grid.Col span={12}>
            <Tooltip
              label="Select a predefined panel or enter custom values below"
              position="top"
              withArrow
            >
              <Select
                label="Select Panel Model"
                placeholder="Choose a panel model"
                data={panelModels.map(panel => panel.label)}
                value={selectedPanel}
                onChange={handlePanelSelect}
                clearable
                size="md"
                rightSection={selectedPanel && <IconCheck size={16} />}
                styles={{
                  input: {
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      borderColor: 'var(--mantine-color-blue-5)'
                    }
                  }
                }}
              />
            </Tooltip>
          </Grid.Col>

          <Grid.Col span={6}>
            <NumberInput
              label="Display Width (mm)"
              placeholder="Enter display width"
              value={inputs.displayWidth}
              onChange={(value) => handleInputChange('displayWidth', value)}
              min={1}
              required
              size="md"
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <NumberInput
              label="Display Height (mm)"
              placeholder="Enter display height"
              value={inputs.displayHeight}
              onChange={(value) => handleInputChange('displayHeight', value)}
              min={1}
              required
              size="md"
            />
          </Grid.Col>

          <Grid.Col span={6}>
            <NumberInput
              label="Panel Width (mm)"
              placeholder="Enter panel width"
              value={inputs.panelWidth}
              onChange={(value) => handleInputChange('panelWidth', value)}
              min={1}
              required
              size="md"
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <NumberInput
              label="Panel Height (mm)"
              placeholder="Enter panel height"
              value={inputs.panelHeight}
              onChange={(value) => handleInputChange('panelHeight', value)}
              min={1}
              required
              size="md"
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <NumberInput
              label="Panel Resolution Width (px)"
              placeholder="Enter panel resolution width"
              value={inputs.panelResWidth}
              onChange={(value) => handleInputChange('panelResWidth', value)}
              min={1}
              required
              size="md"
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <NumberInput
              label="Panel Resolution Height (px)"
              placeholder="Enter panel resolution height"
              value={inputs.panelResHeight}
              onChange={(value) => handleInputChange('panelResHeight', value)}
              min={1}
              required
              size="md"
            />
          </Grid.Col>
        </Grid>

        {error && (
          <Text color="red" size="sm" mt="md">
            {error}
          </Text>
        )}

        <Button
          fullWidth
          onClick={handleCalculate}
          mt="xl"
          size="lg"
          variant="gradient"
          gradient={{ from: 'blue', to: 'cyan' }}
          sx={{
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-2px)',
              boxShadow: '0 5px 15px rgba(0, 123, 255, 0.4)'
            }
          }}
        >
          Calculate
        </Button>

        {results && (
          <Paper withBorder p="xl" mt="xl" radius="md" sx={{ 
            transition: 'all 0.3s ease',
            animation: 'fadeIn 0.3s ease-in-out'
          }}>
            <Title order={3} mb="lg" align="center">Results for After Effects</Title>
            <Grid>
              <Grid.Col span={6}>
                <Text weight={600} size="lg">Horizontal Pixels:</Text>
                <Text size="xl">{results.horizontalPixels}</Text>
              </Grid.Col>
              <Grid.Col span={6}>
                <Text weight={600} size="lg">Vertical Pixels:</Text>
                <Text size="xl">{results.verticalPixels}</Text>
              </Grid.Col>
              <Grid.Col span={12} mt="md">
                <Text weight={600} size="lg">Total Pixel Count:</Text>
                <Text size="xl">{results.totalPixels.toLocaleString()}</Text>
              </Grid.Col>
            </Grid>
          </Paper>
        )}
      </Paper>
    </Container>
  )
}
import { Box, CircularProgress, Typography } from '@mui/material';
import { useImageStore } from '../store/imageStore';

export default function ImageWorkspace({ dropzoneProps, isProcessing }) {
  const { getRootProps, getInputProps, isDragActive } = dropzoneProps;
  const image = useImageStore(state => state.image);
  const layers = useImageStore(state => state.layers);

  return (
    <Box
      {...getRootProps()}
      sx={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        border: '2px dashed',
        borderColor: isDragActive ? 'primary.main' : 'grey.300',
        borderRadius: 1,
        p: 2,
        position: 'relative',
        backgroundColor: '#fafafa',
        '&:hover': {
          borderColor: 'primary.main',
          cursor: 'pointer'
        }
      }}
    >
      <input {...getInputProps()} />
      
      {isProcessing ? (
        <Box sx={{ textAlign: 'center' }}>
          <CircularProgress />
          <Typography sx={{ mt: 2 }}>Processing image...</Typography>
        </Box>
      ) : layers.length > 0 ? (
        <Box sx={{ position: 'relative', width: '100%', height: '100%' }}>
          {layers.map((layer) => (
            layer.visible && (
              <Box
                key={layer.id}
                component="img"
                src={layer.data}
                sx={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  height: '100%',
                  objectFit: 'contain'
                }}
              />
            )
          ))}
        </Box>
      ) : image ? (
        <Box
          component="img"
          src={image}
          sx={{
            maxWidth: '100%',
            maxHeight: '100%',
            objectFit: 'contain'
          }}
        />
      ) : (
        <Typography color="text.secondary">
          {isDragActive
            ? "Drop the image here..."
            : "Drag and drop an image here, or click to select"}
        </Typography>
      )}
    </Box>
  );
}
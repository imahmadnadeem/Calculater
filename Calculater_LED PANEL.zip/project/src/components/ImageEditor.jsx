import { useState, useCallback, useRef } from 'react';
import { Box, Paper, Typography, Slider, Button } from '@mui/material';
import { useDropzone } from 'react-dropzone';
import ImageWorkspace from './ImageWorkspace';
import LayerPanel from './LayerPanel';
import { useImageStore } from '../store/imageStore';
import UndoIcon from '@mui/icons-material/Undo';
import RedoIcon from '@mui/icons-material/Redo';

export default function ImageEditor() {
  const [isProcessing, setIsProcessing] = useState(false);
  const imageRef = useRef(null);
  const setImage = useImageStore(state => state.setImage);
  const processImage = useImageStore(state => state.processImage);
  const undo = useImageStore(state => state.undo);
  const redo = useImageStore(state => state.redo);

  const onDrop = useCallback(async (acceptedFiles) => {
    if (acceptedFiles.length === 0) return;

    setIsProcessing(true);
    const file = acceptedFiles[0];
    const imageUrl = URL.createObjectURL(file);

    try {
      setImage(imageUrl);
      const img = new Image();
      img.onload = async () => {
        await processImage(img);
        setIsProcessing(false);
      };
      img.src = imageUrl;
      imageRef.current = img;
    } catch (error) {
      console.error('Error processing image:', error);
      setIsProcessing(false);
    }
  }, [setImage, processImage]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png']
    },
    multiple: false
  });

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, height: 'calc(100vh - 128px)' }}>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <Button
          startIcon={<UndoIcon />}
          onClick={undo}
          variant="outlined"
        >
          Undo
        </Button>
        <Button
          startIcon={<RedoIcon />}
          onClick={redo}
          variant="outlined"
        >
          Redo
        </Button>
      </Box>
      
      <Box sx={{ display: 'flex', gap: 2, flex: 1 }}>
        <Paper 
          sx={{ 
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden'
          }}
        >
          <ImageWorkspace 
            dropzoneProps={{ getRootProps, getInputProps, isDragActive }}
            isProcessing={isProcessing}
          />
        </Paper>
        <LayerPanel />
      </Box>
    </Box>
  );
}
import { expect, test } from 'vitest'
import { calculateDisplayResolution } from '../utils/calculations'

test('calculates display resolution correctly', () => {
  const result = calculateDisplayResolution(1000, 500, 250, 250, 64, 64)
  expect(result.horizontalPixels).toBe(256)
  expect(result.verticalPixels).toBe(128)
  expect(result.totalPixels).toBe(32768)
})

test('handles decimal results by rounding', () => {
  const result = calculateDisplayResolution(1000, 500, 300, 200, 64, 64)
  expect(result.horizontalPixels).toBe(213) // rounds from 213.33...
  expect(result.verticalPixels).toBe(160)
  expect(result.totalPixels).toBe(34080)
})

test('throws error for invalid inputs', () => {
  expect(() => calculateDisplayResolution(0, 500, 250, 250, 64, 64))
    .toThrow('All inputs must be positive numbers')
  expect(() => calculateDisplayResolution(-1000, 500, 250, 250, 64, 64))
    .toThrow('All inputs must be positive numbers')
  expect(() => calculateDisplayResolution('invalid', 500, 250, 250, 64, 64))
    .toThrow('All inputs must be positive numbers')
})
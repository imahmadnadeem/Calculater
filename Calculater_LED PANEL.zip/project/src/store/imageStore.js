import { create } from 'zustand';
import { segmentImage } from '../utils/segmentation';
import { adjustImageLayer } from '../utils/imageProcessing';

export const useImageStore = create((set, get) => ({
  image: null,
  layers: [],
  history: [],
  currentHistoryIndex: -1,
  
  setImage: (image) => set({ image }),
  
  setLayers: (layers) => {
    const state = get();
    set({
      layers,
      history: [...state.history.slice(0, state.currentHistoryIndex + 1), layers],
      currentHistoryIndex: state.currentHistoryIndex + 1
    });
  },
  
  processImage: async (imageElement) => {
    try {
      const { foreground, background } = await segmentImage(imageElement);
      const layers = [
        {
          id: 'background',
          name: 'Background',
          visible: true,
          locked: false,
          data: background,
          adjustments: { brightness: 0, contrast: 0 }
        },
        {
          id: 'foreground',
          name: 'Subject',
          visible: true,
          locked: false,
          data: foreground,
          adjustments: { brightness: 0, contrast: 0 }
        }
      ];
      get().setLayers(layers);
    } catch (error) {
      console.error('Error processing image:', error);
    }
  },
  
  adjustLayer: async (layerId, adjustments) => {
    const state = get();
    const layerIndex = state.layers.findIndex(layer => layer.id === layerId);
    if (layerIndex === -1) return;
    
    const layer = state.layers[layerIndex];
    const newData = await adjustImageLayer(layer.data, adjustments);
    
    const newLayers = [...state.layers];
    newLayers[layerIndex] = {
      ...layer,
      data: newData,
      adjustments: { ...layer.adjustments, ...adjustments }
    };
    
    get().setLayers(newLayers);
  },
  
  toggleLayerVisibility: (layerId) => {
    const state = get();
    const newLayers = state.layers.map(layer =>
      layer.id === layerId
        ? { ...layer, visible: !layer.visible }
        : layer
    );
    get().setLayers(newLayers);
  },
  
  toggleLayerLock: (layerId) => {
    const state = get();
    const newLayers = state.layers.map(layer =>
      layer.id === layerId
        ? { ...layer, locked: !layer.locked }
        : layer
    );
    get().setLayers(newLayers);
  },
  
  undo: () => {
    const state = get();
    if (state.currentHistoryIndex > 0) {
      set({
        layers: state.history[state.currentHistoryIndex - 1],
        currentHistoryIndex: state.currentHistoryIndex - 1
      });
    }
  },
  
  redo: () => {
    const state = get();
    if (state.currentHistoryIndex < state.history.length - 1) {
      set({
        layers: state.history[state.currentHistoryIndex + 1],
        currentHistoryIndex: state.currentHistoryIndex + 1
      });
    }
  }
}));